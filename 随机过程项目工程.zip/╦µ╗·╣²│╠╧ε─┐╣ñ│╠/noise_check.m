I=imread('Abramites_hypselonotus_0017_wpsͼƬ.jpg');
%I=imnoise(I,'gaussian');
[B c r]=roipoly(I);
imhist(I(B));