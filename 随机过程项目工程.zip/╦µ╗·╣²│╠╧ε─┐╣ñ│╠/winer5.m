%I=imread('Abudefduf_sexfasciatus_0034.jpg');
%I=imread('Arripis_trutta_0032.jpg');
I=imread('Abudefduf_bengalensis_0007.jpg');
I=rgb2gray(I);
J=imnoise(I,'gaussian',0,0.2);
%J=imnoise(I,'speckle',0.02);
%J=imnoise(I,'salt & pepper',0.2);
K2=filter2(fspecial('average',3),J)/255; 
K= medfilt2(J);
K1=wiener2(J);
subplot(2,3,1);imshow(I);
title('ԭʼͼ��');
subplot(2,3,2);imshow(J);
title('����ͼ��');
subplot(2,3,3);imshow(K2);
title('��ֵ�˲����ͼ��');
subplot(2,3,4);imshow(K);
title('��ֵ�˲����ͼ��');
subplot(2,3,5);imshow(K1);
title('ά���˲����ͼ��');
[PSNR1, MSE1] = psnr(I, J);
PSNR1
MSE1
[PSNR2, MSE2] = psnr(double(I), double(K2));
[PSNR3, MSE3] = psnr(I, K);
[PSNR4, MSE4] = psnr(I, K1);
PSNR2
MSE2
PSNR3
MSE3
PSNR4
MSE4