function [ PSNR ] = imPSNR( J , I )
%imPSNR Summary of this function goes here
%   I is a image with high quality
%   J is a image with noise
%   the function will return the PSNR of the noise image
width = size(I,2);
heigh = size(I,1);
if( width ~= size(J,2) || heigh ~= size(J,1) )
    disp('Please check the input image have the same size');
    return
end
K = (I-J).*(I-J);
PSNR = sum(sum(K,1));
PSNR = PSNR / (width * heigh);
PSNR=10*log10(255*255/PSNR);
endf = imread('Arripis_trutta_0032.jpg');
subplot(231);imshow(f);title('lena��ɫԭͼ');
g = rgb2gray(f);
subplot(234);imshow(g),title('lena�Ҷ�ԭͼ');
n = imnoise(g,'salt & pepper',0.01);
subplot(232);imshow(n),title('����ͼ��');
m1 = medfilt2(n,[5 5]);
subplot(235);imshow(m1),title('5*5��ֵ�˲�');
m2 = medfilt2(n,[5 1]);
subplot(233);imshow(m2);title('5*1��ֵ�˲�');
m3 = medfilt2(n,[1 5]);
subplot(236);imshow(m3);title('����˲���');
[imPSNR(n,g),imPSNR(m1,g),imPSNR(m3,g),imPSNR(g,g);
 imKBlur(n,g),imKBlur(m1,g),imKBlur(m3,g),imKBlur(g,g)]